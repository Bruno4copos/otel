# Gonum diff

[![go.dev reference](https://pkg.go.dev/badge/gonum.org/v1/gonum/diff)](https://pkg.go.dev/gonum.org/v1/gonum/diff)
[![GoDoc](https://godocs.io/gonum.org/v1/gonum/diff?status.svg)](https://godocs.io/gonum.org/v1/gonum/diff)

Package diff is a package for computing derivatives of functions for the Go language.
