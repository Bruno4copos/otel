
0.0.3 / 2013-07-26 
==================

  * [bugfix] Fix to enable the binding to be used with HDRI/OpenEXR version of ImageMagick (#1)

0.0.2 / 2013-05-06 
==================

  * Fix README formatting

0.0.1 / 2013-05-06 
==================

  * Minimum supported version of ImageMagick is now 6.7.7 (Ubuntu/Debian)

pre-0.0.1
==================

  * See git log if needed
