package types

type Increaser interface {
	IncreaseCount()
}
