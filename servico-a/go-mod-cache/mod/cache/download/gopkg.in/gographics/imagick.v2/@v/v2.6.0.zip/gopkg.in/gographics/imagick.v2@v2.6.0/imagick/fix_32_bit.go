// +build 386

package imagick

//#cgo CFLAGS: -DMAGICKCORE_SIZEOF_FLOAT_T=MAGICKCORE_SIZEOF_DOUBLE
import "C"
