package types

type Decreaser interface {
	DecreaseCount()
}
