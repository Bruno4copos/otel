package types

type Clearer interface {
	Clear()
}
